//Tara Moses
//Assignment 3.1: ASCII Art
//June 20, 2013

public class ASCII
{
	public static void main(String[] args)
	{
		System.out.println("-----3.1: ASCII ART-----");
		System.out.println("\n         _  o o\n         \\ \\|/ _,\n      __.\'   /`_/\n    /`    u   ;#\n    `c-_..__,/ ##\n           );:\'##\n           |   ##\n           |:.:##\n           |.  ##\n           |:.\'##\n           |.::##\n          /  \' ##\n          |.:\'  ##\n          ;::\' .:#\n         / \'     \'#\n         |  .: \'::.`\'-..__\n         |:.         .::\' `\',\n         |:::   \':.       .:,\\\n          \\ \', .  .::\' .::  | |\n          |\'.|.:|  \'     \'  /\\#\n          |  \\ \'|._.::  |   |##\n          | /|.:|  `\"\";`| .:|##\n          / ||  /     | ;  \'|\n          \\ // |      \\:\'\\  |\n          | /\\ /       ; ;| \\\n          | || |       | || /\n          | || |       | || |\n         _/ j| |      _/ J| |\n        (/_/_/ J     (/_/_/ j\n           (/_/         (/_/\n");
	}
}
